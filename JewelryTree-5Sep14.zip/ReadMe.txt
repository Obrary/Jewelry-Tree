Product: Jewelry Tree, September 2014
Designer: Scott Austin, scotta@obrary.com
Support:  support@obrary.com
Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Jewelry Tree is designed to be cut from acrylic on a Laser Cutter.

Files included in this package:
 - JewelryTree.skp - this is the model of the Jewelry Tree in SketchUp.  SketchUp can be installed for free at http://www.sketchup.com/download
 - JewelryTree.dxf - this is the 2D plan of the design that can be opened in a variety of applications
 - JewelryTree.pdf - another format of the 2D plan of the design
 - ReadMe.txt - this file